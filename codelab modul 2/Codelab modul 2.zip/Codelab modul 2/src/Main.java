import java.util.ArrayList;
import java.util.Scanner;

// Class Mahasiswa untuk merepresentasikan objek mahasiswa
class Mahasiswa {
    // Atribut untuk NIM, nama, dan jurusan mahasiswa
    private String nim;
    private String nama;
    private String jurusan;

    // Constructor untuk objek Mahasiswa
    public Mahasiswa(String nim, String nama, String jurusan) {
        this.nim = nim;
        this.nama = nama;
        this.jurusan = jurusan;
    }

    // Getter untuk NIM
    public String getNim() {
        return nim;
    }

    // Setter untuk NIM dengan validasi panjang NIM
    public void setNim(String nim) {
        if (nim.length() < 15 && nim.length() > 0) {
            this.nim = nim;
        } else {
            System.out.println("NIM harus memiliki panjang antara 1 sampai 15 digit.");
        }
    }

    // Getter untuk nama
    public String getNama() {
        return nama;
    }

    // Setter untuk nama
    public void setNama(String nama) {
        this.nama = nama;
    }

    // Getter untuk jurusan
    public String getJurusan() {
        return jurusan;
    }

    // Setter untuk jurusan
    public void setJurusan(String jurusan) {
        this.jurusan = jurusan;
    }

    // Method static untuk menampilkan nama universitas
    public static void tampilUniversitas() {
        System.out.println("Universitas Muhammadiyah Malang");
    }

    // Method untuk representasi string objek Mahasiswa
    @Override
    public String toString() {
        return "Nama: " + nama + ", NIM: " + nim + ", Jurusan: " + jurusan;
    }
}

// Class Main sebagai entry point program
public class Main {
    public static void main(String[] args) {
        // Scanner untuk input dari pengguna
        Scanner scanner = new Scanner(System.in);
        // ArrayList untuk menyimpan data mahasiswa
        ArrayList<Mahasiswa> listMahasiswa = new ArrayList<>();
        // Variabel untuk menyimpan pilihan pengguna
        int pilihan;
        // Variabel untuk menyimpan NIM, nama, dan jurusan mahasiswa
        String nim, nama, jurusan;

        // Perulangan utama program
        do {
            // Menampilkan menu
            System.out.println("\n=== MENU ===");
            System.out.println("1. Tambah Data Mahasiswa");
            System.out.println("2. Tampilkan Data Mahasiswa");
            System.out.println("3. Keluar");
            System.out.print("Masukkan pilihan anda: ");
            // Membaca pilihan pengguna
            pilihan = scanner.nextInt();

            // Switch case untuk memproses pilihan pengguna
            switch (pilihan) {
                case 1:
                    scanner.nextLine();
                    // Meminta input nama mahasiswa
                    System.out.print("Masukkan nama mahasiswa: ");
                    nama = scanner.nextLine();
                    // Meminta input NIM mahasiswa
                    System.out.print("Masukkan NIM mahasiswa: ");
                    nim = scanner.nextLine();
                    // Memanggil method untuk menampilkan universitas
                    Mahasiswa.tampilUniversitas();
                    // Meminta input jurusan mahasiswa
                    System.out.print("Masukkan jurusan mahasiswa: ");
                    jurusan = scanner.nextLine();
                    // Menambahkan data mahasiswa ke dalam ArrayList
                    listMahasiswa.add(new Mahasiswa(nim, nama, jurusan));
                    // Menampilkan pesan bahwa data berhasil ditambahkan
                    System.out.println("Data mahasiswa berhasil ditambahkan.");
                    break;
                case 2:
                    // Memeriksa apakah ArrayList kosong
                    if (listMahasiswa.isEmpty()) {
                        System.out.println("Belum ada data mahasiswa.");
                    } else {
                        // Menampilkan data mahasiswa
                        System.out.println("\nData Mahasiswa:");
                        for (Mahasiswa mahasiswa : listMahasiswa) {
                            System.out.println(mahasiswa.toString());
                        }
                    }
                    break;
                case 3:
                    // Menampilkan pesan bahwa program berakhir
                    System.out.println("Terima kasih telah menggunakan program ini.");
                    break;
                default:
                    // Menampilkan pesan jika pilihan tidak valid
                    System.out.println("Pilihan tidak valid.");
            }
        } while (pilihan != 3); // Mengulang jika pilihan bukan 3

        // Menutup scanner
        scanner.close();
    }
}
